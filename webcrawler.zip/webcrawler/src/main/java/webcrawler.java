
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class webcrawler {
    private static final int MAX_DEPTH = 2; // Limit the depth to prevent excessive crawling
    private static final Set<String> visitedUrls = new HashSet<>(); // Track visited URLs to avoid duplication

    public static void main(String[] args) {
        String startUrl = "https://example.com"; // Replace with the URL you want to crawl
        String outputFilePath = "crawler_output.txt"; // Path to the output file

        try (FileWriter writer = new FileWriter(outputFilePath)) {
            System.out.println("Starting crawl at: " + startUrl);
            writer.write("Starting crawl at: " + startUrl + "\n\n");
            crawl(startUrl, 0, writer); // Begin the DFS crawl
            System.out.println("\nCrawl complete. Output saved to: " + outputFilePath);
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }

    /**
     * Recursive method to crawl the web page.
     *
     * @param url    The URL to crawl.
     * @param depth  The current depth of the crawl.
     * @param writer The FileWriter to write the output to.
     */
    public static void crawl(String url, int depth, FileWriter writer) {
        // Stop if we've reached the maximum depth
        if (depth > MAX_DEPTH) {
            return;
        }

        // Avoid revisiting URLs
        if (visitedUrls.contains(url)) {
            return;
        }

        // Mark this URL as visited
        visitedUrls.add(url);

        try {
            // Fetch the HTML document
            Document document = Jsoup.connect(url).get();

            // Print and write the title and URL of the current page
            String pageTitle = document.title();
            String pageHeader = "=== Page Title: " + pageTitle + " ===\nPage URL: " + url + "\n";
            System.out.println("\n" + pageHeader);
            writer.write(pageHeader + "\n");

            // Extract all links on the current page
            Elements links = document.select("a[href]");
            writer.write("Links:\n");

            for (Element link : links) {
                String linkHref = link.absUrl("href").trim(); // Get absolute URL of the link
                String linkText = link.text().trim(); // Get the text of the link

                // Print and write the hyperlink in the desired format
                String output = "    - title: " + linkText + " | URL: " + linkHref;
                System.out.println(output);
                writer.write(output + "\n");

                // Perform DFS on the new link
                if (!visitedUrls.contains(linkHref) && !linkHref.isEmpty()) {
                    crawl(linkHref, depth + 1, writer);
                }
            }

            writer.write("\n--- End of Page ---\n\n");
            System.out.println("--- End of Page ---");
        } catch (IOException e) {
            System.err.println("Error fetching URL: " + url + " | " + e.getMessage());
        }
    }
}
